import subprocess

class HiveNetwork:
    def __init__(self):
        pass

    def create_network(self):
        return subprocess.run(['podman', 'network', 'create', 'hive'], check=True)

    def check_network(self):
        return subprocess.run(['podman', 'network', 'exists', 'hive'], check=True)

    def delete_network(self):
        return subprocess.run(['podman', 'network', 'rm', 'hive'], check=True)

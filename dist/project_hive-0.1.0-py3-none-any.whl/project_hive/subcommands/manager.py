import typer
from ..services.hive_network import HiveNetwork

app = typer.Typer()


@app.command()
def create():
    """Create a new Hive project."""
    print(f"Creating a new Hive project")
    HiveNetwork().create_network()

# @app.command()
# def init():
#     pass

# @app.command()
# def start():
#     pass

# @app.command()
# def restart():
#     pass

# @app.command()
# def stop():
#     pass

# @app.command()
# def delete():
#     pass

# @app.command()
# def status():
#     pass